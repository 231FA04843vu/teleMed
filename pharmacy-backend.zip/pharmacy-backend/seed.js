import fs from "fs";
import mongoose from "mongoose";
import dotenv from "dotenv";
import Medicine from "./models/Medicine.js";

dotenv.config();

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log("✅ MongoDB connected for seeding");

    // Read JSON dataset
    const data = JSON.parse(fs.readFileSync("medicines.json", "utf-8"));

    // Clear old data
    await Medicine.deleteMany({});
    console.log("🗑️ Old data cleared");

    // Insert new dataset
    await Medicine.insertMany(data);
    console.log(`✅ Inserted ${data.length} medicines`);

    process.exit();
  } catch (err) {
    console.error("❌ Error seeding data:", err);
    process.exit(1);
  }
};

seedData();
