import axios from "axios";
import { GoogleGenerativeAI } from "@google/generative-ai";

const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_ID;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);

// ✅ Send WhatsApp Message
export const sendMessage = async (req, res) => {
  const { to, message } = req.body;

  try {
    const response = await axios.post(
      `https://graph.facebook.com/v19.0/${PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: "whatsapp",
        to,
        text: { body: message },
      },
      {
        headers: {
          Authorization: `Bearer ${WHATSAPP_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (err) {
    console.error("Error sending message:", err.response?.data || err.message);
    res.status(500).json({ error: err.response?.data || err.message });
  }
};

// ✅ Receive WhatsApp Messages (Webhook)
export const receiveWebhook = async (req, res) => {
  try {
    const changes = req.body.entry?.[0]?.changes?.[0]?.value?.messages;

    if (changes && changes.length > 0) {
      const msg = changes[0];
      const userMsg = msg.text?.body;
      const from = msg.from;

      let reply = "❓ Sorry, I didn't understand that.";

      if (userMsg.toLowerCase().includes("appointment")) {
        reply = "✅ Your appointment has been booked! We’ll notify you with details.";
        // TODO: integrate with your appointment booking DB logic
      } else {
        // Use Gemini Pro for AI prescription
        try {
          const model = genAI.getGenerativeModel({ model: "gemini-pro" });
          const result = await model.generateContent(
            `The patient says: ${userMsg}. 
            Act as a healthcare assistant and generate a basic prescription-style response.
            Include possible conditions, suggested tests if relevant, and basic medication/advice.`
          );
          reply = result.response.text();
        } catch (err) {
          console.error("Gemini API Error:", err.message);
          reply = "⚠️ Sorry, I couldn’t generate a prescription right now.";
        }
      }

      // send reply to WhatsApp
      await axios.post(
        `https://graph.facebook.com/v19.0/${PHONE_NUMBER_ID}/messages`,
        {
          messaging_product: "whatsapp",
          to: from,
          text: { body: reply },
        },
        {
          headers: {
            Authorization: `Bearer ${WHATSAPP_TOKEN}`,
            "Content-Type": "application/json",
          },
        }
      );
    }

    res.sendStatus(200);
  } catch (error) {
    console.error("Webhook error:", error.message);
    res.sendStatus(500);
  }
};
