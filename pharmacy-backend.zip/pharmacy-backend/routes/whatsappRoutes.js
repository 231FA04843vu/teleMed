import express from "express";
import { sendMessage, receiveWebhook } from "../controllers/whatsappController.js";

const router = express.Router();

// ✅ Send message manually (for testing)
router.post("/send", sendMessage);

// ✅ Webhook for incoming WhatsApp messages
router.post("/webhook", receiveWebhook);

export default router;
