import mongoose from "mongoose";

const medicineSchema = new mongoose.Schema({
  genericName: { type: String, required: true },
  brandName: { type: String },
  strength: { type: String },
  manufacturer: { type: String },
  price: { type: Number },
  quantity: { type: Number, default: 0 },
  minStock: { type: Number, default: 10 },
  expiryDate: { type: Date }
}, { timestamps: true });

const Medicine = mongoose.model("Medicine", medicineSchema);
export default Medicine;
