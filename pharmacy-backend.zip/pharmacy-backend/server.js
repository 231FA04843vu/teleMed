import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import medicineRoutes from "./routes/medicineRoutes.js";
import authRoutes from "./routes/authRoutes.js"; // New auth routes
import whatsappRoutes from "./routes/whatsappRoutes.js";

dotenv.config();
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/medicines", medicineRoutes);
app.use("/api/auth", authRoutes); // <-- Added authentication routes
app.use("/api/whatsapp", whatsappRoutes);

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("✅ MongoDB Connected"))
.catch(err => console.error("❌ MongoDB Error:", err));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
